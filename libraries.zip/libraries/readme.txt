For information on installing libraries, see: http://arduino.cc/en/Guide/Libraries
